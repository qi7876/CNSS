# ADO.NET code examples

https://docs.microsoft.com/en-us/dotnet/framework/data/adonet/ado-net-code-examples
